package com.example.academicaffairssystem.ui.inquire;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class InquireViewModel extends ViewModel {

    private final MutableLiveData<String> mText;

    public InquireViewModel() {
        mText = new MutableLiveData<>();
       // mText.setValue("This is inquire fragment");
    }

    public LiveData<String> getText() {
        return mText;
    }
}