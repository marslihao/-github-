package com.example.academicaffairssystem.ui.inform;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import com.example.academicaffairssystem.R;
import com.example.academicaffairssystem.databinding.FragmentDashboardBinding;

public class InformFragment extends Fragment {

    private FragmentDashboardBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        InformViewModel informViewModel =
                new ViewModelProvider(this).get(InformViewModel.class);

        binding = FragmentDashboardBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        final TextView textView = binding.textDashboard;

        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 获取 NavController，用于控制导航操作
                NavController navController = Navigation.findNavController(v);

                // 使用 NavController 进行导航，从 fragmentA 导航到 fragmentB2
                navController.navigate(R.id.action_navigation_inform_to_navigation_forum);
            }
        });

        informViewModel.getText().observe(getViewLifecycleOwner(), textView::setText);
        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}