package com.example.academicaffairssystem.ui.inquire;

// 导入所需的类
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import com.example.academicaffairssystem.R;
import com.example.academicaffairssystem.databinding.FragmentInquireBinding;

// 定义一个名为 HomeFragment 的类，继承自 Fragment
public class InquireFragment extends Fragment {

    // 声明一个 FragmentInquireBinding 类型的变量，用于绑定布局
    private FragmentInquireBinding binding;

    // 重写 onCreateView 方法，当 Fragment 的视图被创建时调用
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        // 使用 ViewModelProvider 获取 HomeViewModel 的实例
        InquireViewModel inquireViewModel =
                new ViewModelProvider(this).get(InquireViewModel.class);

        // 使用 LayoutInflater 来膨胀布局文件 fragment_inquire.xml，并返回一个 binding 对象
        binding = FragmentInquireBinding.inflate(inflater, container, false);
        // 获取根视图
        View root = binding.getRoot();

        // 获取布局中的 TextView 控件
        final TextView textView = binding.textHome;

        //点击文本，实现跳转功能
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 获取 NavController，用于控制导航操作
                NavController navController = Navigation.findNavController(v);

                // 使用 NavController 进行导航，从 fragmentA 导航到 fragmentB2
                navController.navigate(R.id.action_navigation_inquire_to_navigation_inform);
            }
        });

        // 观察 ViewModel 中的 LiveData 对象，当数据变化时更新 TextView 的文本
        inquireViewModel.getText().observe(getViewLifecycleOwner(), textView::setText);

        // 返回根视图
        return root;
    }

    // 重写 onDestroyView 方法，当 Fragment 的视图被销毁时调用
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        // 解除绑定，以防止内存泄漏
        binding = null;
    }
}
